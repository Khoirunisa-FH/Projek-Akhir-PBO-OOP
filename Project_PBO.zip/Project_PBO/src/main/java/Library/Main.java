package Library;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Main {

    static Database database;

    public static void main(String[] args) {

        database = new Database();

        JFrame frame = frame(500, 420);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 1, 0, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 25, 25, 25));
        panel.setBackground(null);

        JLabel title = label("Welcome to Library Management System");
        title.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        title.setFont(new Font("Tahoma", Font.BOLD, 21));
        title.setForeground(Color.decode("#1da1f2"));
        frame.getContentPane().add(title, BorderLayout.NORTH);

        JLabel label1 = label("Phone Number:");
        JLabel label3 = label("Email:");
        JTextField phonenumber = textfield();
        JTextField password = textfield();
        JButton login = button("Login");
	JButton adminRegistrationButton = Main.button("Register as Admin");
        JButton userRegistrationButton = Main.button("Register as User");

        // Validasi hanya angka pada nomor telepon
        phonenumber.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {  
                    e.consume();
                }
            }
        });

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (phonenumber.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Phone number cannot be empty!");
                    return;
                }
                if (password.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Password cannot be empty!");
                    return;
                }
                login(phonenumber.getText().toString(), password.getText().toString(), frame);
            }
        });
        adminRegistrationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerAdmin();
            }
        });
        
        userRegistrationButton.addActionListener(new ActionListener() {		
            @Override
            public void actionPerformed(ActionEvent e) {
		registerUser();
            }
        });

        panel.add(label1);
        panel.add(phonenumber);
        panel.add(label3);
        panel.add(password);
        panel.add(login);
        panel.add(adminRegistrationButton);
        panel.add(userRegistrationButton);

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private static void login(String phonenumber, String password, JFrame frame) {
        int n = database.login(phonenumber, password);
        if (n != -1) {
            User user = database.getUser(n);
            user.menu(database, user);
            frame.dispose();
        } else {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid login credentials!");
        }
    }

    private static void registerAdmin() {

        JFrame frame = frame(500, 450);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 25, 25, 25));
        panel.setBackground(null);

        JLabel title = label("Create New Account");
        title.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        title.setFont(new Font("Tahoma", Font.BOLD, 21));
        title.setForeground(Color.decode("#1da1f2"));
        frame.getContentPane().add(title, BorderLayout.NORTH);

        JLabel label0 = label("Name:");
        JLabel label1 = label("Phone Number:");
        JLabel label2 = label("Email:");
        JLabel label3 = label("Password:");
        JLabel label4 = label("Admin Code:");
        JTextField name = textfield();
        JTextField phonenumber = textfield();
        JTextField email = textfield();
        JTextField password = textfield();
        JTextField admincode = textfield();
        JButton createacc = button("Create Admin Account");
        JButton cancel = button("Cancel");

        // Validasi hanya huruf pada nama
        name.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' ') {  
                    e.consume();
                }
            }
        });

        // Validasi hanya angka pada nomor telepon
        phonenumber.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) { 
                    e.consume();
                }
            }
        });


        panel.add(label0);
        panel.add(name);
        panel.add(label1);
        panel.add(phonenumber);
        panel.add(label2);
        panel.add(email);
        panel.add(label3);
        panel.add(password);
        panel.add(label4);
        panel.add(admincode);
        panel.add(createacc);
        panel.add(cancel);

        createacc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (database.userExists(name.getText().toString())) {
                    JOptionPane.showMessageDialog(new JFrame(), "Username exists!\nTry another one");
                    return;
                }
                if (name.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Name cannot be empty!");
                    return;
                }
                if (phonenumber.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Phone number cannot be empty!");
                    return;
                }
                if (email.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Email cannot be empty!");
                    return;
                }
                if (password.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Password cannot be empty!");
                    return;
                }
                if (admincode.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(new JFrame(), "Admin code cannot be empty!");
                    return;
                } else if (!admincode.getText().equals("ADMIN123")){
                    JOptionPane.showMessageDialog(new JFrame(), "Incorrect admin code.\nPlease try again!");
                    return;
                }

                Admin admin = new Admin(name.getText(), email.getText(), phonenumber.getText());
                database.AddUser(admin);
                frame.dispose();
                admin.menu(database, admin);
            }
        });
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
    
    private static void registerUser (){
        JFrame frame = frame(500, 380);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 25, 25, 25));
        panel.setBackground(null);

        JLabel title = label("Create New Account");
        title.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        title.setFont(new Font("Tahoma", Font.BOLD, 21));
        title.setForeground(Color.decode("#1da1f2"));
        frame.getContentPane().add(title, BorderLayout.NORTH);

        JLabel label0 = label("Name:");
        JLabel label1 = label("Phone Number:");
        JLabel label2 = label("Email:");
        JLabel label3 = label("Password:");
        JTextField name = textfield();
        JTextField phonenumber = textfield();
        JTextField email = textfield();
        JTextField password = textfield();
        JButton createacc = button("Create User Account");
        JButton cancel = button("Cancel");

        // Validasi hanya huruf pada nama
        name.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' ') {  
                    e.consume();
                }
            }
        });

        // Validasi hanya angka pada nomor telepon
        phonenumber.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {  
                    e.consume();
                }
            }
        });


        panel.add(label0);
        panel.add(name);
        panel.add(label1);
        panel.add(phonenumber);
        panel.add(label2);
        panel.add(email);
        panel.add(label3);
        panel.add(password);
        panel.add(createacc);
        panel.add(cancel);

        createacc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (database.userExists(name.getText().toString())) {
                    JOptionPane.showMessageDialog(new JFrame(), "Username exists!\nTry another one");
                    return;
                }
                if (name.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Name cannot be empty!");
                    return;
                }
                if (phonenumber.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Phone number cannot be empty!");
                    return;
                }
                if (email.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Email cannot be empty!");
                    return;
                }
                if (password.getText().toString().matches("")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Password cannot be empty!");
                    return;
                }

                NormalUser user = new NormalUser(name.getText(), email.getText(), phonenumber.getText());
                database.AddUser(user);
                frame.dispose();
                user.menu(database, user);
            }
        });
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
        
    }

    public static JFrame frame(int width, int height) {
        JFrame frame = new JFrame();
        frame.setSize(width, height);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setTitle("Library Management System");
        frame.setLayout(new BorderLayout());
        frame.setBackground(Color.white);
        frame.getContentPane().setBackground(Color.white);
        return frame;
    }

    public static JLabel label(String text) {
        JLabel label1 = new JLabel(text);
        label1.setHorizontalAlignment(SwingConstants.CENTER);
        label1.setFont(new Font("Tahoma", Font.BOLD, 17));
        label1.setForeground(Color.black);
        return label1;
    }

    public static JTextField textfield() {
        JTextField textfield1 = new JTextField();
        textfield1.setFont(new Font("Tahoma", Font.BOLD, 17));
        textfield1.setForeground(Color.black);
        textfield1.setHorizontalAlignment(SwingConstants.CENTER);
        return textfield1;
    }

    public static JButton button(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Tahoma", Font.BOLD, 17));
        button.setForeground(Color.white);
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setBackground(Color.decode("#1da1f2"));
        button.setBorder(null);
        return button;
    }

    public static JRadioButton radioButton(String text) {
        JRadioButton btn = new JRadioButton();
        btn.setForeground(Color.black);
        btn.setText(text);
        btn.setHorizontalAlignment(SwingConstants.CENTER);
        btn.setFont(new Font("Tahoma", Font.BOLD, 17));
        btn.setBackground(null);
        return btn;
    }

    public static JLabel title(String text) {
        JLabel title = Main.label(text);
        title.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        title.setFont(new Font("Tahoma", Font.BOLD, 21));
        title.setForeground(Color.decode("#1da1f2"));
        return title;
    }

}