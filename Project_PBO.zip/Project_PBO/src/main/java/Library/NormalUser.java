package Library;

import javax.swing.JFrame;

public class NormalUser extends User {
    public NormalUser(String name) {
        super(name);
        this.operations = new IOOperation[] {
            new ViewBooks(),
            new Search(),
            new PlaceOrder(),
            new BorrowBook(),
            new CalculateFine(),
            new ReturnBook(),
            new Exit()
        };
    }

    public NormalUser(String name, String email, String phonenumber) {
        super(name, email, phonenumber);
        this.operations = new IOOperation[] {
            new ViewBooks(),
            new Search(),
            new PlaceOrder(),
            new BorrowBook(),
            new CalculateFine(),
            new ReturnBook(),
            new Exit()
        };
    }

    @Override
    public void menu(Database database, User user) {
        userMenu(database, user);
    }
    
    @Override
    public String toString() {
        return name + "<N/>" + email + "<N/>" + phonenumber + "<N/>Normal";
    }
}