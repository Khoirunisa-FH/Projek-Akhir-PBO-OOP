package Library;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Exit implements IOOperation {
	
	Database database;

	@Override
	public void oper(Database database, User user) {
		JFrame frame = Main.frame(500, 420);
		
		this.database = new Database();
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(7, 1, 0, 5));
		panel.setBorder(BorderFactory.createEmptyBorder(5, 25, 25, 25));
		panel.setBackground(null);
		
		JLabel title = Main.label("Welcome to Library Management System");
		title.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		title.setFont(new Font("Tahoma", Font.BOLD, 21));
		title.setForeground(Color.decode("#1da1f2"));
		frame.getContentPane().add(title, BorderLayout.NORTH);
                
		JLabel label1 = Main.label ("Phone Number");
                JLabel label3 = Main.label ("Email:");
                JTextField phonenumber = Main.textfield();
                JTextField password = Main.textfield();
		JButton login = Main.button("Login");
		JButton adminRegistrationButton = Main.button("Register as Admin");
                JButton userRegistrationButton = Main.button("Register as User");
                
                // Validasi hanya angka pada nomor telepon
                phonenumber.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!Character.isDigit(c)) {  
                            e.consume();
                       }
                    }
                });
		
		login.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				if (phonenumber.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Phone number cannot be empty!");
					return;
				}
				if (password.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Password cannot be empty!");
					return;
				}
				login(phonenumber.getText().toString(), password.getText().toString(), frame);
			}	
		});
		adminRegistrationButton.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				registerAdmin();
			}	
		});
		userRegistrationButton.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				registerUser();
                        }
                });
                
                
		panel.add(label1);
		panel.add(phonenumber);
		panel.add(label3);
		panel.add(password);	
		panel.add(login);
		panel.add(adminRegistrationButton);
                panel.add(userRegistrationButton);
		
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		frame.setVisible(true);
	}
	
	private void login(String phonenumber, String password, JFrame frame) {
		int n = database.login(phonenumber, password);
		if (n != -1) {
			User user = database.getUser(n);
			user.menu(database, user);
			frame.dispose();
		} else {
			JOptionPane.showMessageDialog(new JFrame(), "User doesn't exist");
		}
	}
	
	private void registerAdmin() {
		
		JFrame frame = Main.frame(500, 450);
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(6, 1, 15, 15));
		panel.setBorder(BorderFactory.createEmptyBorder(5, 25, 25, 25));
		panel.setBackground(null);
		
		JLabel title = Main.label("Create New Account");
		title.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		title.setFont(new Font("Tahoma", Font.BOLD, 21));
		title.setForeground(Color.decode("#1da1f2"));
		frame.getContentPane().add(title, BorderLayout.NORTH);
		
		JLabel label0 = Main.label("Name:");
		JLabel label1 = Main.label("Phone Number:");
		JLabel label2 = Main.label("Email:");
                JLabel label3 = Main.label("Password:");
                JLabel label4 = Main.label("Admin Code:");
		JTextField name = Main.textfield();
		JTextField phonenumber = Main.textfield();
		JTextField email = Main.textfield();
                JTextField password = Main.textfield();
                JTextField admincode = Main.textfield();
		JButton createacc = Main.button("Create Admin Account");
		JButton cancel = Main.button("Cancel");
                
                // Validasi hanya huruf pada nama
                name.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!Character.isLetter(c) && c != ' ') {  
                            e.consume();
                        }
                    }
                });

                // Validasi hanya angka pada nomor telepon
                phonenumber.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!Character.isDigit(c)) {  
                            e.consume();
                        }
                    }
                });
		
		panel.add(label0);
		panel.add(name);
		panel.add(label1);
		panel.add(phonenumber);
		panel.add(label2);
		panel.add(email);
                panel.add(label3);
                panel.add(password);
                panel.add(label4);
                panel.add(admincode);
		panel.add(createacc);
		panel.add(cancel);
		
		createacc.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				if (database.userExists(name.getText().toString())) {
					JOptionPane.showMessageDialog(new JFrame(), "Username exists!\nTry another one");
					return;
				}
				if (name.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Name cannot be empty!");
					return;
				}
				if (phonenumber.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Phone number cannot be empty!");
					return;
				}
				if (email.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Email cannot be empty!");
					return;
                                }
                                if (password.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Password cannot be empty!");
					return;
                                }
                                if (!admincode.getText().equals("ADMIN123")) {
					JOptionPane.showMessageDialog(new JFrame(), "Admin Code cannot be empty!");
					return;
                                }
                                Admin admin = new Admin(name.getText(), email.getText(), phonenumber.getText());
                                database.AddUser(admin);
				frame.dispose();
				admin.menu(database, admin);		
			}
		});
                
		cancel.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		frame.setVisible(true);
	}
        
        private void registerUser() {
                JFrame frame = Main.frame(500, 380);
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(5, 1, 15, 15));
		panel.setBorder(BorderFactory.createEmptyBorder(5, 25, 25, 25));
		panel.setBackground(null);
		
		JLabel title = Main.label("Create New Account");
		title.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		title.setFont(new Font("Tahoma", Font.BOLD, 21));
		title.setForeground(Color.decode("#1da1f2"));
		frame.getContentPane().add(title, BorderLayout.NORTH);
		
		JLabel label0 = Main.label("Name:");
		JLabel label1 = Main.label("Phone Number:");
		JLabel label2 = Main.label("Email:");
                JLabel label3 = Main.label("Password:");
		JTextField name = Main.textfield();
		JTextField phonenumber = Main.textfield();
		JTextField email = Main.textfield();
                JTextField password = Main.textfield();
		JButton createacc = Main.button("Create User Account");
		JButton cancel = Main.button("Cancel");
                
                // Validasi hanya huruf pada nama
                name.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!Character.isLetter(c) && c != ' ') {  
                            e.consume();
                        }
                    }
                });

                // Validasi hanya angka pada nomor telepon
                phonenumber.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!Character.isDigit(c)) { 
                            e.consume();
                        }
                    }
                }); 
		
		panel.add(label0);
		panel.add(name);
		panel.add(label1);
		panel.add(phonenumber);
		panel.add(label2);
		panel.add(email);
                panel.add(label3);
                panel.add(password);
		panel.add(createacc);
		panel.add(cancel);
		
		createacc.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				if (database.userExists(name.getText().toString())) {
					JOptionPane.showMessageDialog(new JFrame(), "Username exists!\nTry another one");
					return;
				}
				if (name.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Name cannot be empty!");
					return;
				}
				if (phonenumber.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Phone number cannot be empty!");
					return;
				}
				if (email.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Email cannot be empty!");
					return;
                                }
                                if (password.getText().toString().matches("")) {
					JOptionPane.showMessageDialog(new JFrame(), "Password cannot be empty!");
					return;
                                }
                                NormalUser user = new NormalUser(name.getText(), email.getText(), phonenumber.getText());
                                database.AddUser(user);
				frame.dispose();
				user.menu(database, user);		
			}
		});
                
		cancel.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		frame.setVisible(true);
                
        }

}

